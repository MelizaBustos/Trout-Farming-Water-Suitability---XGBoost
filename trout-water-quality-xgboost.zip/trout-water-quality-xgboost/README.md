# Trout Water Quality — XGBoost Suitability Model

Water quality monitoring data from five sampling points (P1–P5), with the code for the full analysis: descriptive statistics, a trout suitability classification, and an XGBoost model that predicts whether the water is **SUITABLE** or **NOT SUITABLE** for trout farming.

## Files

| File | Description |
|---|---|
| `Data.csv` | Water quality measurements at P1–P5 (`;` separator) |
| `Data_Analysis.py` | Full analysis code (exported from Google Colab) |

## Data (`Data.csv`)

- **40,817 records**, roughly one every 15 minutes.
- **Period:** April 15, 2025 to June 17, 2026.
- **Sampling points:** P1 to P5, about 8,100 records each.
- No missing values.
- Columns are separated by semicolons (`;`).

| Column | Description |
|---|---|
| `created_at` | Measurement date and time (UTC−05:00) |
| `punto` | Sampling point (P1–P5) |
| `entry_id` | Measurement ID |
| `Temperature` | Water temperature (°C) |
| `pH` | pH |
| `Oxigeno Disuelto` | Dissolved oxygen (mg/L) |

## Analysis steps (`Data_Analysis.py`)

1. **Descriptive analysis:** data quality checks, global and per-point statistics, boxplots, histograms, daily trends, correlations, and outlier detection (IQR).
2. **Trout suitability classification.** A measurement is SUITABLE (`APTO`) only if it meets all three criteria:

   | Variable | Suitable range |
   |---|---|
   | Temperature | 10 – 17 °C |
   | pH | 6.5 – 9.0 |
   | Dissolved oxygen | > 5.5 mg/L |

3. **XGBoost model:**
   - Input features: `temperatura`, `ph`, `oxigeno_disuelto`.
   - Leave-One-Group-Out cross-validation: each sampling point is used once as an independent test set.
   - Metrics: accuracy, precision, recall, F1-score, and ROC-AUC.
   - Figures: confusion matrix, ROC curve, training curves, and feature importance.
   - The final model is trained on all of P1–P5 and saved with `joblib`.

## How to run

### Google Colab
Open the script in Colab and run it. Upload `Data.csv` when prompted. Results are saved to Google Drive under `MyDrive/Calidad de agua/Calidad de agua 2`.

### Locally
```bash
pip install pandas numpy matplotlib seaborn scikit-learn xgboost joblib
```
The script was written for Colab, so make these changes first:
- Replace the file upload with `df = pd.read_csv("Data.csv", sep=";")`.
- Remove the `from google.colab import ...` and `drive.mount(...)` lines.
- Set `OUTPUT_DIR` and `ruta_salida` to a local folder, such as `"results"`.
- Run it in Jupyter, because it uses `display()`.
